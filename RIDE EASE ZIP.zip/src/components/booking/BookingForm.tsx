import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LocationInput from '../route/LocationInput';
import DateTimeInput from './DateTimeInput';
import TransportTypeSelect from './TransportTypeSelect';
import UserDetailsInput from '../route/UserDetailsInput';
import { useBooking } from '../../context/BookingContext';

export default function BookingForm() {
  const navigate = useNavigate();
  const { setBookingDetails } = useBooking();
  const [formData, setFormData] = useState({
    name: '',
    aadhaar: '',
    phone: '',
    startPoint: '',
    destination: '',
    date: '',
    time: '',
    transportType: '',
    passengers: 1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingDetails(formData);
    navigate('/bookings/payment', { 
      state: { 
        fare: calculateFare(formData)
      } 
    });
  };

  const calculateFare = (booking: any) => {
    const baseFare = {
      bus: 50,
      train: 100,
      metro: 30,
      taxi: 500
    }[booking.transportType] || 100;
    
    return baseFare * booking.passengers;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <UserDetailsInput
        name={formData.name}
        aadhaar={formData.aadhaar}
        phone={formData.phone}
        onChange={handleChange}
      />

      <LocationInput
        label="Starting Point"
        id="startPoint"
        value={formData.startPoint}
        onChange={handleChange}
        placeholder="Enter pickup location"
      />

      <LocationInput
        label="Destination"
        id="destination"
        value={formData.destination}
        onChange={handleChange}
        placeholder="Enter drop-off location"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateTimeInput
          label="Date"
          id="date"
          type="date"
          value={formData.date}
          onChange={handleChange}
          min={new Date().toISOString().split('T')[0]}
        />

        <DateTimeInput
          label="Time"
          id="time"
          type="time"
          value={formData.time}
          onChange={handleChange}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TransportTypeSelect
          value={formData.transportType}
          onChange={handleChange}
        />

        <div>
          <label htmlFor="passengers" className="block text-sm font-medium text-gray-700 mb-1">
            Number of Passengers
          </label>
          <input
            type="number"
            id="passengers"
            name="passengers"
            value={formData.passengers}
            onChange={handleChange}
            min="1"
            max="10"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            required
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        Continue to Payment
      </button>
    </form>
  );
}