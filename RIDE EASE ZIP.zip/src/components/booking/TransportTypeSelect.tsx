import React from 'react';

interface TransportTypeSelectProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

export default function TransportTypeSelect({
  value,
  onChange
}: TransportTypeSelectProps) {
  return (
    <div>
      <label htmlFor="transportType" className="block text-sm font-medium text-gray-700 mb-1">
        Transport Type
      </label>
      <select
        id="transportType"
        name="transportType"
        value={value}
        onChange={onChange}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        required
      >
        <option value="">Select transport type</option>
        <option value="bus">Bus</option>
        <option value="train">Train</option>
        <option value="metro">Metro</option>
        <option value="taxi">Taxi</option>
      </select>
    </div>
  );
}