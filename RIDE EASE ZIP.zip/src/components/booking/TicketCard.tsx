import React from 'react';
import { Ticket, Calendar, MapPin } from 'lucide-react';
import type { Ticket as TicketType } from '../../types';

interface TicketCardProps {
  ticket: TicketType;
  onStatusChange: (ticketId: string, status: TicketType['status']) => void;
}

export default function TicketCard({ ticket, onStatusChange }: TicketCardProps) {
  const statusColors = {
    upcoming: 'bg-green-100 text-green-800',
    completed: 'bg-gray-100 text-gray-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <Ticket className="w-6 h-6 text-indigo-600 mr-2" />
          <div>
            <h3 className="font-semibold">Booking #{ticket.bookingId}</h3>
            <p className="text-sm text-gray-600">{ticket.transportType}</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm ${statusColors[ticket.status]}`}>
          {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
        </span>
      </div>

      <div className="space-y-3">
        <div className="flex items-center text-gray-600">
          <MapPin className="w-5 h-5 mr-2" />
          <div>
            <p className="text-sm">From: <span className="font-medium">{ticket.from}</span></p>
            <p className="text-sm">To: <span className="font-medium">{ticket.to}</span></p>
          </div>
        </div>

        <div className="flex items-center text-gray-600">
          <Calendar className="w-5 h-5 mr-2" />
          <div>
            <p className="text-sm">Date: <span className="font-medium">{ticket.date}</span></p>
            <p className="text-sm">Time: <span className="font-medium">{ticket.time}</span></p>
          </div>
        </div>

        <div className="border-t pt-3 mt-3">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600">Amount Paid</p>
              <p className="font-semibold">₹{ticket.fare}</p>
            </div>
            {ticket.status === 'upcoming' && (
              <div className="space-x-2">
                <button
                  onClick={() => onStatusChange(ticket.id, 'completed')}
                  className="px-3 py-1 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Complete
                </button>
                <button
                  onClick={() => onStatusChange(ticket.id, 'cancelled')}
                  className="px-3 py-1 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}