import React from 'react';
import { Download } from 'lucide-react';
import { generateTicketPDF, downloadTicket } from '../../utils/pdf';
import { Ticket } from '../../types';

interface DownloadTicketProps {
  ticket: Ticket;
}

export default function DownloadTicket({ ticket }: DownloadTicketProps) {
  const handleDownload = () => {
    try {
      const pdfOutput = generateTicketPDF(ticket);
      downloadTicket(pdfOutput, `RideEase-Ticket-${ticket.bookingId}.pdf`);
    } catch (error) {
      console.error('Error generating ticket:', error);
      alert('Failed to generate ticket. Please try again.');
    }
  };

  return (
    <button
      onClick={handleDownload}
      className="flex items-center justify-center w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors"
    >
      <Download className="w-5 h-5 mr-2" />
      Download Ticket
    </button>
  );
}