import React from 'react';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  type: 'user' | 'bot';
  content: string;
}

export default function ChatMessage({ type, content }: ChatMessageProps) {
  const isBot = type === 'bot';
  
  return (
    <div className={`flex ${isBot ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex max-w-[80%] ${isBot ? 'flex-row' : 'flex-row-reverse'}`}>
        <div className={`flex-shrink-0 ${isBot ? 'mr-2' : 'ml-2'}`}>
          {isBot ? (
            <div className="bg-indigo-100 p-2 rounded-full">
              <Bot className="w-5 h-5 text-indigo-600" />
            </div>
          ) : (
            <div className="bg-gray-100 p-2 rounded-full">
              <User className="w-5 h-5 text-gray-600" />
            </div>
          )}
        </div>
        <div
          className={`p-3 rounded-lg ${
            isBot
              ? 'bg-gray-100 text-gray-800'
              : 'bg-indigo-600 text-white'
          }`}
        >
          {content}
        </div>
      </div>
    </div>
  );
}