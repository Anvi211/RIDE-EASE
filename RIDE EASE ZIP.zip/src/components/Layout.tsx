import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { Bus, Map, Users, Calendar, Home, Car } from 'lucide-react';

const Navigation = () => (
  <nav className="bg-indigo-600 text-white">
    <div className="max-w-7xl mx-auto px-4">
      <div className="flex items-center justify-between h-16">
        <Link to="/" className="flex items-center space-x-2">
          <Bus className="w-8 h-8" />
          <span className="text-xl font-bold">RideEase</span>
        </Link>
        <div className="flex space-x-4">
          <Link to="/" className="flex items-center space-x-1 hover:text-indigo-200">
            <Home className="w-5 h-5" />
            <span>Home</span>
          </Link>
          <Link to="/routes/plan" className="flex items-center space-x-1 hover:text-indigo-200">
            <Map className="w-5 h-5" />
            <span>Routes</span>
          </Link>
          <Link to="/bookings" className="flex items-center space-x-1 hover:text-indigo-200">
            <Calendar className="w-5 h-5" />
            <span>Bookings</span>
          </Link>
          <Link to="/carpools" className="flex items-center space-x-1 hover:text-indigo-200">
            <Car className="w-5 h-5" />
            <span>Carpooling</span>
          </Link>
          <Link to="/community" className="flex items-center space-x-1 hover:text-indigo-200">
            <Users className="w-5 h-5" />
            <span>Community</span>
          </Link>
        </div>
      </div>
    </div>
  </nav>
);

export default function Layout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Outlet />
      </main>
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About RideEase</h3>
              <p className="text-gray-300">Simplifying urban commuting with real-time tracking, route planning, and booking options.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/routes/plan" className="text-gray-300 hover:text-white">Route Planning</Link></li>
                <li><Link to="/bookings" className="text-gray-300 hover:text-white">My Bookings</Link></li>
                <li><Link to="/carpools" className="text-gray-300 hover:text-white">Carpooling</Link></li>
                <li><Link to="/community" className="text-gray-300 hover:text-white">Community</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <p className="text-gray-300">Email: support@rideease.com</p>
              <p className="text-gray-300">Emergency: 1800-RIDE-HELP</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}