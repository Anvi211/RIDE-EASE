import React from 'react';
import { MessageSquare, ThumbsUp } from 'lucide-react';

export default function DiscussionBoard() {
  const discussions = [
    {
      author: 'Sarah K.',
      topic: 'Best routes to avoid traffic',
      replies: 23,
      likes: 45,
      timeAgo: '2h ago',
    },
    {
      author: 'Mike R.',
      topic: 'Evening commute buddy needed',
      replies: 15,
      likes: 32,
      timeAgo: '4h ago',
    },
    {
      author: 'Alex M.',
      topic: 'New bus route feedback',
      replies: 34,
      likes: 67,
      timeAgo: '6h ago',
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center mb-6">
        <MessageSquare className="w-6 h-6 text-indigo-600 mr-2" />
        <h2 className="text-2xl font-semibold">Discussion Board</h2>
      </div>
      <div className="space-y-4">
        {discussions.map((discussion, index) => (
          <div key={index} className="border-b last:border-0 pb-4 last:pb-0">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold text-gray-900">{discussion.topic}</h3>
              <span className="text-sm text-gray-500">{discussion.timeAgo}</span>
            </div>
            <p className="text-gray-600 mb-2">Posted by {discussion.author}</p>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center">
                <MessageSquare className="w-4 h-4 mr-1" />
                <span>{discussion.replies} replies</span>
              </div>
              <div className="flex items-center">
                <ThumbsUp className="w-4 h-4 mr-1" />
                <span>{discussion.likes} likes</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}