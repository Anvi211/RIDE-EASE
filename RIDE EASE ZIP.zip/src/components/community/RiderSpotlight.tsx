import React from 'react';
import { Award, Star } from 'lucide-react';

export default function RiderSpotlight() {
  const spotlightRiders = [
    {
      name: 'David Chen',
      achievement: 'Most Eco-friendly Commuter',
      description: 'Saved 500kg CO2 this month by choosing public transport',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200',
    },
    {
      name: 'Lisa Wong',
      achievement: 'Community Helper',
      description: 'Helped 50+ new commuters find optimal routes',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200&h=200',
    },
    {
      name: 'James Wilson',
      achievement: 'Route Master',
      description: 'Shared 100+ route optimizations',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200&h=200',
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center mb-6">
        <Award className="w-6 h-6 text-indigo-600 mr-2" />
        <h2 className="text-2xl font-semibold">Rider Spotlight</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {spotlightRiders.map((rider, index) => (
          <div key={index} className="text-center">
            <img
              src={rider.image}
              alt={rider.name}
              className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
            />
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{rider.name}</h3>
            <div className="flex items-center justify-center text-yellow-500 mb-2">
              <Star className="w-4 h-4 fill-current" />
              <span className="ml-1 text-indigo-600 font-medium">{rider.achievement}</span>
            </div>
            <p className="text-gray-600 text-sm">{rider.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}