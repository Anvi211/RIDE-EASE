import React from 'react';
import { Calendar, MapPin, Users } from 'lucide-react';

export default function CommunityEvents() {
  const events = [
    {
      title: 'Eco-Commute Week',
      date: 'March 15-21, 2024',
      location: 'Citywide',
      participants: 234,
      description: 'Join the movement for sustainable commuting',
    },
    {
      title: 'Commuter Meetup',
      date: 'March 25, 2024',
      location: 'Central Park',
      participants: 89,
      description: 'Network with fellow commuters and share experiences',
    },
    {
      title: 'Transit Tech Workshop',
      date: 'April 2, 2024',
      location: 'Tech Hub',
      participants: 156,
      description: 'Learn about the latest in transportation technology',
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center mb-6">
        <Calendar className="w-6 h-6 text-indigo-600 mr-2" />
        <h2 className="text-2xl font-semibold">Upcoming Events</h2>
      </div>
      <div className="space-y-6">
        {events.map((event, index) => (
          <div key={index} className="border-b last:border-0 pb-4 last:pb-0">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{event.title}</h3>
            <div className="flex items-center text-gray-600 mb-2">
              <Calendar className="w-4 h-4 mr-2" />
              <span>{event.date}</span>
            </div>
            <div className="flex items-center text-gray-600 mb-2">
              <MapPin className="w-4 h-4 mr-2" />
              <span>{event.location}</span>
            </div>
            <div className="flex items-center text-gray-600 mb-2">
              <Users className="w-4 h-4 mr-2" />
              <span>{event.participants} participants</span>
            </div>
            <p className="text-gray-600">{event.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}