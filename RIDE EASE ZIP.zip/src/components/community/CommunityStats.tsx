import React from 'react';
import { Users, Route, Clock, ThumbsUp } from 'lucide-react';

export default function CommunityStats() {
  const stats = [
    { icon: <Users className="w-8 h-8" />, value: '10K+', label: 'Active Members' },
    { icon: <Route className="w-8 h-8" />, value: '50K+', label: 'Routes Shared' },
    { icon: <Clock className="w-8 h-8" />, value: '100K+', label: 'Hours Saved' },
    { icon: <ThumbsUp className="w-8 h-8" />, value: '95%', label: 'Satisfaction' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div key={index} className="bg-white rounded-xl shadow-md p-6 text-center">
          <div className="flex justify-center text-indigo-600 mb-4">{stat.icon}</div>
          <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
          <div className="text-gray-600">{stat.label}</div>
        </div>
      ))}
    </div>
  );
}