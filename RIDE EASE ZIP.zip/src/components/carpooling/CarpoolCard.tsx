import React from 'react';
import { Car, Calendar, Clock, Users, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Carpool } from '../../types';

interface CarpoolCardProps {
  carpool: Carpool;
}

export default function CarpoolCard({ carpool }: CarpoolCardProps) {
  const navigate = useNavigate();

  const handleJoinCarpool = () => {
    navigate(`/carpools/${carpool.id}/join`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex items-center">
            <Car className="w-5 h-5 text-indigo-600 mr-2" />
            <h3 className="text-lg font-semibold">{carpool.carModel}</h3>
          </div>
          <p className="text-gray-600">{carpool.carNumber}</p>
        </div>
        <span className="text-lg font-bold text-indigo-600">₹{carpool.price}/seat</span>
      </div>

      <div className="space-y-3">
        <div className="flex items-center text-gray-600">
          <MapPin className="w-5 h-5 mr-2" />
          <div>
            <p className="text-sm">From: <span className="font-medium">{carpool.startPoint}</span></p>
            <p className="text-sm">To: <span className="font-medium">{carpool.destination}</span></p>
          </div>
        </div>

        <div className="flex items-center text-gray-600">
          <Calendar className="w-5 h-5 mr-2" />
          <span>{carpool.date}</span>
          <Clock className="w-5 h-5 ml-4 mr-2" />
          <span>{carpool.time}</span>
        </div>

        <div className="flex items-center text-gray-600">
          <Users className="w-5 h-5 mr-2" />
          <span>{carpool.availableSeats} seats available</span>
        </div>

        {carpool.description && (
          <p className="text-gray-600 text-sm border-t pt-3">
            {carpool.description}
          </p>
        )}
      </div>

      <button
        onClick={handleJoinCarpool}
        className="w-full mt-4 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        Join Carpool
      </button>
    </div>
  );
}