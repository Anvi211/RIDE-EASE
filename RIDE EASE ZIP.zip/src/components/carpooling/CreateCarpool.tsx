import React, { useState } from 'react';
import { Car, Calendar, Clock, Users, MapPin } from 'lucide-react';
import LocationInput from '../route/LocationInput';
import DateTimeInput from '../booking/DateTimeInput';

export default function CreateCarpool() {
  const [carpoolData, setCarpoolData] = useState({
    startPoint: '',
    destination: '',
    date: '',
    time: '',
    seats: 1,
    price: '',
    carModel: '',
    carNumber: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle carpool creation
    console.log('Creating carpool:', carpoolData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setCarpoolData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center mb-6">
        <Car className="w-6 h-6 text-indigo-600 mr-2" />
        <h2 className="text-xl font-semibold">Offer a Carpool Ride</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <LocationInput
            label="Starting Point"
            id="startPoint"
            value={carpoolData.startPoint}
            onChange={handleChange}
            placeholder="Enter pickup location"
          />

          <LocationInput
            label="Destination"
            id="destination"
            value={carpoolData.destination}
            onChange={handleChange}
            placeholder="Enter drop-off location"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <DateTimeInput
            label="Date"
            id="date"
            type="date"
            value={carpoolData.date}
            onChange={handleChange}
            min={new Date().toISOString().split('T')[0]}
          />

          <DateTimeInput
            label="Time"
            id="time"
            type="time"
            value={carpoolData.time}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Available Seats
            </label>
            <div className="relative">
              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="number"
                name="seats"
                min="1"
                max="6"
                value={carpoolData.seats}
                onChange={handleChange}
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Price per Seat
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">₹</span>
              <input
                type="number"
                name="price"
                min="0"
                value={carpoolData.price}
                onChange={handleChange}
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Car Model
            </label>
            <input
              type="text"
              name="carModel"
              value={carpoolData.carModel}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g., Honda Civic"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Car Number
            </label>
            <input
              type="text"
              name="carNumber"
              value={carpoolData.carNumber}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g., KA-01-AB-1234"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Additional Information
          </label>
          <textarea
            name="description"
            value={carpoolData.description}
            onChange={handleChange}
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            placeholder="Add any additional details about the ride..."
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Create Carpool
        </button>
      </form>
    </div>
  );
}