import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin } from 'lucide-react';

interface RouteMapProps {
  from: string;
  to: string;
}

// Fix for default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const defaultCenter = [20.5937, 78.9629]; // Center of India

export default function RouteMap({ from, to }: RouteMapProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <MapPin className="w-5 h-5 text-indigo-600" />
          <span className="ml-2 font-medium">{from}</span>
        </div>
        <div className="border-t-2 border-dashed border-gray-300 flex-grow mx-4" />
        <div className="flex items-center">
          <MapPin className="w-5 h-5 text-indigo-600" />
          <span className="ml-2 font-medium">{to}</span>
        </div>
      </div>
      <div className="h-[400px] w-full rounded-lg overflow-hidden">
        <MapContainer
          center={defaultCenter}
          zoom={5}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
        </MapContainer>
      </div>
    </div>
  );
}