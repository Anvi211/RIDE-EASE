import React from 'react';
import { Clock, Ruler, ThermometerSun } from 'lucide-react';

interface RouteStatsProps {
  duration: number;
  distance: string;
  weather: string;
}

export default function RouteStats({ duration, distance, weather }: RouteStatsProps) {
  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex items-center text-indigo-600 mb-2">
          <Clock className="w-5 h-5 mr-2" />
          <span className="font-medium">Duration</span>
        </div>
        <p className="text-2xl font-bold">{duration} min</p>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex items-center text-indigo-600 mb-2">
          <Ruler className="w-5 h-5 mr-2" />
          <span className="font-medium">Distance</span>
        </div>
        <p className="text-2xl font-bold">{distance}</p>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex items-center text-indigo-600 mb-2">
          <ThermometerSun className="w-5 h-5 mr-2" />
          <span className="font-medium">Weather</span>
        </div>
        <p className="text-2xl font-bold">{weather}</p>
      </div>
    </div>
  );
}