import React from 'react';
import { Bus, Train, Car, Bike } from 'lucide-react';

interface TransportPreferenceProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const transportOptions = [
  { value: 'bus', label: 'Bus', icon: Bus, description: 'Economic & reliable' },
  { value: 'train', label: 'Train', icon: Train, description: 'Fast & comfortable' },
  { value: 'car', label: 'Car', icon: Car, description: 'Private & flexible' },
  { value: 'auto', label: 'Auto', icon: Car, description: 'Quick & convenient' },
  { value: 'bike', label: 'Bike', icon: Bike, description: 'Fast & economical' }
];

export default function TransportPreference({ value, onChange }: TransportPreferenceProps) {
  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-gray-700">
        Preferred Transport
      </label>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {transportOptions.map((option) => (
          <label
            key={option.value}
            className={`
              flex flex-col items-center p-4 border rounded-lg cursor-pointer
              transition-colors hover:border-indigo-500
              ${value === option.value ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'}
            `}
          >
            <input
              type="radio"
              name="preferredTransport"
              value={option.value}
              checked={value === option.value}
              onChange={onChange}
              className="sr-only"
            />
            <option.icon className="w-8 h-8 text-indigo-600 mb-2" />
            <span className="font-medium text-sm">{option.label}</span>
            <span className="text-xs text-gray-500 text-center mt-1">
              {option.description}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}