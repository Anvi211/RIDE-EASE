import React from 'react';
import { Filter } from 'lucide-react';

interface RouteFiltersProps {
  onFilterChange: (type: string) => void;
}

export default function RouteFilters({ onFilterChange }: RouteFiltersProps) {
  return (
    <div className="flex items-center space-x-4 mb-6">
      <Filter className="w-5 h-5 text-gray-500" />
      <button 
        onClick={() => onFilterChange('all')}
        className="px-4 py-2 rounded-full bg-indigo-600 text-white hover:bg-indigo-700"
      >
        All
      </button>
      <button 
        onClick={() => onFilterChange('bus')}
        className="px-4 py-2 rounded-full border border-gray-300 hover:border-indigo-600"
      >
        Bus
      </button>
      <button 
        onClick={() => onFilterChange('train')}
        className="px-4 py-2 rounded-full border border-gray-300 hover:border-indigo-600"
      >
        Train
      </button>
      <button 
        onClick={() => onFilterChange('taxi')}
        className="px-4 py-2 rounded-full border border-gray-300 hover:border-indigo-600"
      >
        Taxi
      </button>
    </div>
  );
}