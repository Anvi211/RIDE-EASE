import React from 'react';
import { Clock, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useBooking } from '../../context/BookingContext';
import { Route } from '../../types';

interface RouteCardProps {
  route: Route;
}

export default function RouteCard({ route }: RouteCardProps) {
  const navigate = useNavigate();
  const { bookingDetails, setBookingDetails } = useBooking();

  const handleBooking = () => {
    if (bookingDetails) {
      setBookingDetails({
        ...bookingDetails,
        transportType: route.type,
        time: route.departureTime,
      });
      navigate('/bookings/payment', { state: { fare: route.fare } });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold">{route.type}</h3>
          <p className="text-gray-600">{route.provider}</p>
        </div>
        <span className="text-lg font-bold text-indigo-600">₹{route.fare}</span>
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center text-gray-600">
          <Clock className="w-5 h-5 mr-2" />
          <span>{route.duration} mins</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Users className="w-5 h-5 mr-2" />
          <span>{route.seatsAvailable} seats available</span>
        </div>

        <div className="border-t pt-3 mt-3">
          <div className="flex justify-between text-sm">
            <div>
              <p className="font-semibold">{route.from}</p>
              <p className="text-gray-500">{route.departureTime}</p>
            </div>
            <div className="text-right">
              <p className="font-semibold">{route.to}</p>
              <p className="text-gray-500">{route.arrivalTime}</p>
            </div>
          </div>
        </div>
      </div>

      <button 
        onClick={handleBooking}
        className="w-full mt-4 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        Book Now
      </button>
    </div>
  );
}