import React from 'react';
import { Cloud, Sun, Thermometer } from 'lucide-react';
import { WeatherInfo as WeatherInfoType } from '../../types';

interface WeatherInfoProps {
  weather: WeatherInfoType | undefined;
  location: string;
}

export default function WeatherInfo({ weather, location }: WeatherInfoProps) {
  if (!weather) {
    return (
      <div className="bg-white rounded-xl shadow-md p-6 animate-pulse">
        <div className="h-24"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Weather at {location}</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {weather.condition === 'Sunny' ? (
              <Sun className="w-8 h-8 text-yellow-500 mr-2" />
            ) : (
              <Cloud className="w-8 h-8 text-gray-500 mr-2" />
            )}
            <span className="text-lg">{weather.condition}</span>
          </div>
          <div className="flex items-center">
            <Thermometer className="w-6 h-6 text-red-500 mr-1" />
            <span className="text-lg font-semibold">{weather.temperature}°C</span>
          </div>
        </div>
        <div className="text-sm text-gray-600">
          Precipitation: {weather.precipitation}%
        </div>
      </div>
    </div>
  );
}