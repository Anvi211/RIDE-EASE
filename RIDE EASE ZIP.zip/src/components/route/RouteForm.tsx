import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LocationInput from './LocationInput';
import UserDetailsInput from './UserDetailsInput';
import TransportPreference from './TransportPreference';
import { useBooking } from '../../context/BookingContext';

export default function RouteForm() {
  const navigate = useNavigate();
  const { setBookingDetails } = useBooking();
  const [formData, setFormData] = useState({
    name: '',
    aadhaar: '',
    phone: '',
    startPoint: '',
    destination: '',
    preferredTransport: '',
    paymentMethod: 'card'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingDetails({
      name: formData.name,
      aadhaar: formData.aadhaar,
      phone: formData.phone,
      startPoint: formData.startPoint,
      destination: formData.destination,
      date: new Date().toISOString().split('T')[0],
      time: '',
      transportType: formData.preferredTransport,
      passengers: 1,
      paymentMethod: formData.paymentMethod
    });
    navigate('/routes/results');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <UserDetailsInput
        name={formData.name}
        aadhaar={formData.aadhaar}
        phone={formData.phone}
        onChange={handleChange}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <LocationInput
          label="Starting Point"
          id="startPoint"
          value={formData.startPoint}
          onChange={handleChange}
          placeholder="Enter starting location"
        />

        <LocationInput
          label="Destination"
          id="destination"
          value={formData.destination}
          onChange={handleChange}
          placeholder="Enter destination"
        />
      </div>

      <TransportPreference
        value={formData.preferredTransport}
        onChange={handleChange}
      />

      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-lg font-semibold mb-3">Payment Method</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:border-indigo-500">
            <input
              type="radio"
              name="paymentMethod"
              value="card"
              checked={formData.paymentMethod === 'card'}
              onChange={handleChange}
              className="mr-2"
            />
            <span>Card</span>
          </label>
          <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:border-indigo-500">
            <input
              type="radio"
              name="paymentMethod"
              value="upi"
              checked={formData.paymentMethod === 'upi'}
              onChange={handleChange}
              className="mr-2"
            />
            <span>UPI</span>
          </label>
          <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:border-indigo-500">
            <input
              type="radio"
              name="paymentMethod"
              value="netbanking"
              checked={formData.paymentMethod === 'netbanking'}
              onChange={handleChange}
              className="mr-2"
            />
            <span>Net Banking</span>
          </label>
          <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:border-indigo-500">
            <input
              type="radio"
              name="paymentMethod"
              value="cash"
              checked={formData.paymentMethod === 'cash'}
              onChange={handleChange}
              className="mr-2"
            />
            <span>Cash</span>
          </label>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        Find Routes
      </button>
    </form>
  );
}