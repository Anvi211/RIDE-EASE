import React from 'react';
import { Bus, Train, Car, Bike } from 'lucide-react';

const transportOptions = [
  {
    type: 'Bus',
    icon: Bus,
    basePrice: 50,
    priceRange: '₹50 - ₹150',
    description: 'Economic & reliable',
    eta: '45 mins'
  },
  {
    type: 'Train',
    icon: Train,
    basePrice: 100,
    priceRange: '₹100 - ₹300',
    description: 'Fast & comfortable',
    eta: '30 mins'
  },
  {
    type: 'Auto',
    icon: Car,
    basePrice: 200,
    priceRange: '₹200 - ₹400',
    description: 'Quick & convenient',
    eta: '35 mins'
  },
  {
    type: 'Bike',
    icon: Bike,
    basePrice: 150,
    priceRange: '₹150 - ₹300',
    description: 'Fast & economical',
    eta: '25 mins'
  }
];

export default function TransportOptions() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {transportOptions.map((option) => (
        <div key={option.type} className="bg-white rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center mb-3">
            <option.icon className="w-6 h-6 text-indigo-600 mr-2" />
            <h3 className="font-semibold">{option.type}</h3>
          </div>
          <div className="space-y-2">
            <p className="text-lg font-bold text-indigo-600">{option.priceRange}</p>
            <p className="text-sm text-gray-600">{option.description}</p>
            <p className="text-sm font-medium">ETA: {option.eta}</p>
          </div>
        </div>
      ))}
    </div>
  );
}