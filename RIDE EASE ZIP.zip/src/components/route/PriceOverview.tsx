import React from 'react';
import { Bus, Train, Car, Bike } from 'lucide-react';

const transportOptions = [
  {
    type: 'Bus',
    icon: Bus,
    basePrice: 50,
    priceRange: '₹50 - ₹150',
    description: 'Economic & reliable'
  },
  {
    type: 'Train',
    icon: Train,
    basePrice: 100,
    priceRange: '₹100 - ₹300',
    description: 'Fast & comfortable'
  },
  {
    type: 'Car',
    icon: Car,
    basePrice: 500,
    priceRange: '₹500 - ₹800',
    description: 'Private & flexible'
  },
  {
    type: 'Auto',
    icon: Car,
    basePrice: 200,
    priceRange: '₹200 - ₹400',
    description: 'Quick & convenient'
  },
  {
    type: 'Bike',
    icon: Bike,
    basePrice: 150,
    priceRange: '₹150 - ₹300',
    description: 'Fast & economical'
  }
];

export default function PriceOverview() {
  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Transport Options & Pricing</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {transportOptions.map((option) => (
          <div key={option.type} className="border rounded-lg p-4 hover:border-indigo-500 transition-colors">
            <div className="flex items-center mb-3">
              <option.icon className="w-6 h-6 text-indigo-600 mr-2" />
              <h3 className="font-semibold">{option.type}</h3>
            </div>
            <div className="text-lg font-bold text-indigo-600 mb-1">
              {option.priceRange}
            </div>
            <p className="text-sm text-gray-600">{option.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}