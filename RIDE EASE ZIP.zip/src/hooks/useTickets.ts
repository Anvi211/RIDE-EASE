import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Ticket } from '../types';

const TICKETS_KEY = 'tickets';

// Simulate localStorage as our "database"
const getStoredTickets = (): Ticket[] => {
  const stored = localStorage.getItem(TICKETS_KEY);
  return stored ? JSON.parse(stored) : [];
};

const storeTickets = (tickets: Ticket[]) => {
  localStorage.setItem(TICKETS_KEY, JSON.stringify(tickets));
};

export function useTickets() {
  const queryClient = useQueryClient();

  const { data: tickets = [] } = useQuery({
    queryKey: ['tickets'],
    queryFn: getStoredTickets,
  });

  const addTicket = useMutation({
    mutationFn: (newTicket: Omit<Ticket, 'id'>) => {
      const ticket: Ticket = {
        ...newTicket,
        id: Math.random().toString(36).substr(2, 9),
      };
      const updatedTickets = [...getStoredTickets(), ticket];
      storeTickets(updatedTickets);
      return ticket;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
    },
  });

  const updateTicketStatus = useMutation({
    mutationFn: ({ ticketId, status }: { ticketId: string; status: Ticket['status'] }) => {
      const tickets = getStoredTickets();
      const updatedTickets = tickets.map(ticket =>
        ticket.id === ticketId ? { ...ticket, status } : ticket
      );
      storeTickets(updatedTickets);
      return updatedTickets;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
    },
  });

  return {
    tickets,
    addTicket,
    updateTicketStatus,
  };
}