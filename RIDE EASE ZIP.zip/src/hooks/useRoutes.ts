import { useQuery } from '@tanstack/react-query';
import { fetchRoutes } from '../services/api';

export function useRoutes(from: string, to: string) {
  return useQuery({
    queryKey: ['routes', from, to],
    queryFn: () => fetchRoutes(from, to),
    enabled: !!from && !!to,
  });
}