import { useQuery } from '@tanstack/react-query';
import { fetchWeather } from '../services/api';

export function useWeather(location: string) {
  return useQuery({
    queryKey: ['weather', location],
    queryFn: () => fetchWeather(location),
    enabled: !!location,
  });
}