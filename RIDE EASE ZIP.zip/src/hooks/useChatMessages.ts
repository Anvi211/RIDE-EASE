import { useState } from 'react';

interface ChatMessage {
  type: 'user' | 'bot';
  content: string;
}

export function useChatMessages() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      type: 'bot',
      content: 'Hi! I'm your RideEase assistant. How can I help you today?',
    },
  ]);

  const addMessage = (message: ChatMessage) => {
    setMessages((prev) => [...prev, message]);
  };

  return { messages, addMessage };
}