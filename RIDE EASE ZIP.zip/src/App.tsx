import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import RoutePlanner from './pages/RoutePlanner';
import BookRide from './pages/BookRide';
import RouteResults from './pages/RouteResults';
import Community from './pages/Community';
import Payment from './pages/Payment';
import BookingConfirmation from './pages/BookingConfirmation';
import Bookings from './pages/Bookings';
import Carpooling from './pages/Carpooling';
import { BookingProvider } from './context/BookingContext';

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BookingProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="/routes/plan" element={<RoutePlanner />} />
              <Route path="/routes/results" element={<RouteResults />} />
              <Route path="/bookings/new" element={<BookRide />} />
              <Route path="/bookings" element={<Bookings />} />
              <Route path="/bookings/payment" element={<Payment />} />
              <Route path="/bookings/confirmation" element={<BookingConfirmation />} />
              <Route path="/community" element={<Community />} />
              <Route path="/carpools" element={<Carpooling />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </BookingProvider>
    </QueryClientProvider>
  );
}