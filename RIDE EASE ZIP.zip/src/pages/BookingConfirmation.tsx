import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckCircle, Calendar, MapPin, Users, CreditCard } from 'lucide-react';
import { useBooking } from '../context/BookingContext';
import { useTickets } from '../hooks/useTickets';
import DownloadTicket from '../components/booking/DownloadTicket';
import type { Ticket } from '../types';

export default function BookingConfirmation() {
  const navigate = useNavigate();
  const { bookingDetails } = useBooking();
  const location = useLocation();
  const { fare = 0 } = location.state || {};
  const { addTicket } = useTickets();
  
  // Generate bookingId once when component mounts
  const bookingId = React.useMemo(() => Math.random().toString(36).substr(2, 9).toUpperCase(), []);
  
  // Create ticket once when component mounts and bookingDetails are available
  const ticket = React.useMemo(() => {
    if (!bookingDetails) return null;
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      bookingId,
      from: bookingDetails.startPoint,
      to: bookingDetails.destination,
      date: bookingDetails.date,
      time: bookingDetails.time || 'Flexible',
      transportType: bookingDetails.transportType,
      passengers: bookingDetails.passengers,
      fare,
      status: 'upcoming',
      paymentMethod: 'card'
    } as Ticket;
  }, [bookingDetails, bookingId, fare]);

  // Add ticket to storage only once when ticket is created
  React.useEffect(() => {
    if (ticket) {
      addTicket.mutate(ticket);
    }
  }, [ticket, addTicket]);

  if (!bookingDetails) {
    return (
      <div className="max-w-md mx-auto mt-8 text-center">
        <p className="text-gray-600">No booking details found.</p>
        <button
          onClick={() => navigate('/bookings/new')}
          className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
        >
          Make a New Booking
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <div className="text-center mb-6">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900">Booking Confirmed!</h1>
          <p className="text-gray-600">Booking ID: {bookingId}</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center">
            <MapPin className="w-5 h-5 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">From</p>
              <p className="font-medium">{bookingDetails.startPoint}</p>
            </div>
          </div>

          <div className="flex items-center">
            <MapPin className="w-5 h-5 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">To</p>
              <p className="font-medium">{bookingDetails.destination}</p>
            </div>
          </div>

          <div className="flex items-center">
            <Calendar className="w-5 h-5 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">Date & Time</p>
              <p className="font-medium">
                {bookingDetails.date} {bookingDetails.time}
              </p>
            </div>
          </div>

          <div className="flex items-center">
            <Users className="w-5 h-5 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">Passengers</p>
              <p className="font-medium">{bookingDetails.passengers}</p>
            </div>
          </div>

          <div className="flex items-center">
            <CreditCard className="w-5 h-5 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">Amount Paid</p>
              <p className="font-medium">₹{fare}</p>
            </div>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          {ticket && <DownloadTicket ticket={ticket} />}
          
          <button
            onClick={() => navigate('/bookings')}
            className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700"
          >
            View My Bookings
          </button>
          
          <button
            onClick={() => navigate('/')}
            className="w-full border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}