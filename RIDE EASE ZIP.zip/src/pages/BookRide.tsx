import React from 'react';
import BookingForm from '../components/booking/BookingForm';
import { Calendar } from 'lucide-react';

export default function BookRide() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Book a Ride</h1>
        <p className="text-gray-600">Reserve your seat in advance for a hassle-free journey</p>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center mb-6">
          <Calendar className="w-6 h-6 text-indigo-600 mr-2" />
          <h2 className="text-xl font-semibold">Booking Details</h2>
        </div>
        <BookingForm />
      </div>
    </div>
  );
}