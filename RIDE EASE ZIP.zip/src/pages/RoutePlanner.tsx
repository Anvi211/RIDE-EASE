import React from 'react';
import RouteForm from '../components/route/RouteForm';
import { MapPin } from 'lucide-react';

export default function RoutePlanner() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Plan Your Route</h1>
        <p className="text-gray-600">Find the best route for your journey with real-time updates</p>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center mb-6">
          <MapPin className="w-6 h-6 text-indigo-600 mr-2" />
          <h2 className="text-xl font-semibold">Route Details</h2>
        </div>
        <RouteForm />
      </div>
    </div>
  );
}