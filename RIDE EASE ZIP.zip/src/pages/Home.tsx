import React from 'react';
import { Search, Clock, Shield, Leaf } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative h-[500px] rounded-xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=2070"
          alt="City transport"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="text-center text-white p-8">
            <h1 className="text-5xl font-bold mb-4">Smart Urban Commuting</h1>
            <p className="text-xl mb-8">Real-time tracking, route planning, and seamless bookings</p>
            <div className="flex justify-center space-x-4">
              <button 
                onClick={() => navigate('/routes/plan')}
                className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Plan Your Route
              </button>
              <button 
                onClick={() => navigate('/bookings/new')}
                className="bg-white text-indigo-600 px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Book a Ride
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}