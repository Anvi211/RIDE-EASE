import React, { useState } from 'react';
import { Ticket, Filter } from 'lucide-react';
import TicketCard from '../components/booking/TicketCard';
import { useTickets } from '../hooks/useTickets';
import type { Ticket as TicketType } from '../types';

export default function Bookings() {
  const { tickets, updateTicketStatus } = useTickets();
  const [filter, setFilter] = useState<TicketType['status'] | 'all'>('all');

  const filteredTickets = tickets.filter(
    ticket => filter === 'all' || ticket.status === filter
  );

  const handleStatusChange = (ticketId: string, status: TicketType['status']) => {
    updateTicketStatus.mutate({ ticketId, status });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Bookings</h1>
        <p className="text-gray-600">View and manage your travel bookings</p>
      </div>

      <div className="mb-6 flex items-center space-x-4">
        <Filter className="w-5 h-5 text-gray-500" />
        {(['all', 'upcoming', 'completed', 'cancelled'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-full ${
              filter === status
                ? 'bg-indigo-600 text-white'
                : 'border border-gray-300 hover:border-indigo-600'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {filteredTickets.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-md">
          <Ticket className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Bookings Found</h3>
          <p className="text-gray-600">You haven't made any bookings yet.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredTickets.map(ticket => (
            <TicketCard
              key={ticket.id}
              ticket={ticket}
              onStatusChange={handleStatusChange}
            />
          ))}
        </div>
      )}
    </div>
  );
}