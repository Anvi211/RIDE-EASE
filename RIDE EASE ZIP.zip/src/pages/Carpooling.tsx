import React, { useState } from 'react';
import { Car, Filter } from 'lucide-react';
import CreateCarpool from '../components/carpooling/CreateCarpool';
import CarpoolCard from '../components/carpooling/CarpoolCard';

// Sample data - In a real app, this would come from an API
const sampleCarpools = [
  {
    id: '1',
    startPoint: 'Indiranagar',
    destination: 'Electronic City',
    date: '2024-03-20',
    time: '09:00',
    availableSeats: 3,
    price: 150,
    carModel: 'Honda City',
    carNumber: 'KA-01-AB-1234',
    description: 'Daily commute to office, AC car',
  },
  {
    id: '2',
    startPoint: 'Whitefield',
    destination: 'MG Road',
    date: '2024-03-20',
    time: '10:00',
    availableSeats: 2,
    price: 200,
    carModel: 'Toyota Innova',
    carNumber: 'KA-02-CD-5678',
    description: 'Comfortable ride, music allowed',
  },
];

export default function Carpooling() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [filter, setFilter] = useState('all');

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Carpooling</h1>
            <p className="text-gray-600">Share rides, save money, reduce traffic</p>
          </div>
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {showCreateForm ? 'View Available Carpools' : 'Offer a Ride'}
          </button>
        </div>
      </div>

      {showCreateForm ? (
        <CreateCarpool />
      ) : (
        <>
          <div className="mb-6 flex items-center space-x-4">
            <Filter className="w-5 h-5 text-gray-500" />
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-full ${
                filter === 'all'
                  ? 'bg-indigo-600 text-white'
                  : 'border border-gray-300 hover:border-indigo-600'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('today')}
              className={`px-4 py-2 rounded-full ${
                filter === 'today'
                  ? 'bg-indigo-600 text-white'
                  : 'border border-gray-300 hover:border-indigo-600'
              }`}
            >
              Today
            </button>
            <button
              onClick={() => setFilter('tomorrow')}
              className={`px-4 py-2 rounded-full ${
                filter === 'tomorrow'
                  ? 'bg-indigo-600 text-white'
                  : 'border border-gray-300 hover:border-indigo-600'
              }`}
            >
              Tomorrow
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sampleCarpools.map(carpool => (
              <CarpoolCard key={carpool.id} carpool={carpool} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}