import React from 'react';
import { Users, MessageSquare, Calendar } from 'lucide-react';
import CommunityEvents from '../components/community/CommunityEvents';
import DiscussionBoard from '../components/community/DiscussionBoard';
import CommunityStats from '../components/community/CommunityStats';

export default function Community() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">RideEase Community</h1>
        <p className="text-xl text-gray-600">Connect with fellow commuters and share your journey</p>
      </div>

      <CommunityStats />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <CommunityEvents />
        <DiscussionBoard />
      </div>
    </div>
  );
}