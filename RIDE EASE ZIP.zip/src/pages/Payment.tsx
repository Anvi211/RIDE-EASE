import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CreditCard, Calendar, Lock, Shield } from 'lucide-react';
import { useBooking } from '../context/BookingContext';

interface PaymentFormData {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  name: string;
}

export default function Payment() {
  const navigate = useNavigate();
  const location = useLocation();
  const { fare = 0 } = location.state || {};
  const { bookingDetails } = useBooking();
  const [paymentDetails, setPaymentDetails] = useState<PaymentFormData>({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    name: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we would process payment here
    navigate('/bookings/confirmation', { state: { fare } });
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Payment</h1>
        <p className="text-gray-600">Secure payment for your booking</p>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <div className="mb-6 border-b pb-4">
          <div className="text-2xl font-bold text-indigo-600">₹{fare}</div>
          <div className="text-gray-600">Total Amount</div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold mb-2">Booking Summary</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-gray-600">From</div>
                <div className="font-medium">{bookingDetails?.startPoint}</div>
              </div>
              <div>
                <div className="text-gray-600">To</div>
                <div className="font-medium">{bookingDetails?.destination}</div>
              </div>
              <div>
                <div className="text-gray-600">Date</div>
                <div className="font-medium">{bookingDetails?.date}</div>
              </div>
              <div>
                <div className="text-gray-600">Time</div>
                <div className="font-medium">{bookingDetails?.time}</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Card Number
            </label>
            <div className="relative">
              <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                maxLength={16}
                pattern="\d*"
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="1234 5678 9012 3456"
                required
                value={paymentDetails.cardNumber}
                onChange={(e) => setPaymentDetails({...paymentDetails, cardNumber: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expiry Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  maxLength={5}
                  className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="MM/YY"
                  required
                  value={paymentDetails.expiryDate}
                  onChange={(e) => setPaymentDetails({...paymentDetails, expiryDate: e.target.value})}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                CVV
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="password"
                  maxLength={3}
                  pattern="\d*"
                  className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="123"
                  required
                  value={paymentDetails.cvv}
                  onChange={(e) => setPaymentDetails({...paymentDetails, cvv: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center text-sm text-gray-600 bg-indigo-50 p-3 rounded-lg">
            <Shield className="w-5 h-5 text-indigo-600 mr-2" />
            Your payment is secured with industry-standard encryption
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Pay ₹{fare} Securely
          </button>
        </form>
      </div>
    </div>
  );
}