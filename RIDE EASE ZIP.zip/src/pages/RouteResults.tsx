import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import RouteCard from '../components/route/RouteCard';
import RouteFilters from '../components/route/RouteFilters';
import RouteMap from '../components/route/RouteMap';
import RouteStats from '../components/route/RouteStats';
import PriceOverview from '../components/route/PriceOverview';
import WeatherInfo from '../components/route/WeatherInfo';
import { useRoutes } from '../hooks/useRoutes';
import { useWeather } from '../hooks/useWeather';

export default function RouteResults() {
  const location = useLocation();
  const { startPoint, destination } = location.state || {};
  const [filterType, setFilterType] = useState('all');

  const { data: routes = [], isLoading: routesLoading } = useRoutes(startPoint, destination);
  const { data: weather } = useWeather(startPoint);

  const filteredRoutes = routes.filter(
    route => filterType === 'all' || route.type === filterType
  );

  if (routesLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Available Routes</h1>
        <p className="text-gray-600">
          Showing routes from {startPoint} to {destination}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="lg:col-span-2">
          <PriceOverview />
        </div>
        <div>
          <WeatherInfo weather={weather} location={startPoint} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <RouteMap from={startPoint} to={destination} />
          <RouteStats 
            duration={30} 
            distance="15 km" 
            weather={weather ? `${weather.condition} ${weather.temperature}°C` : 'Loading...'} 
          />
          <RouteFilters onFilterChange={setFilterType} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredRoutes.map(route => (
              <RouteCard key={route.id} route={route} />
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Route Highlights</h3>
            <ul className="space-y-4">
              <li className="flex items-center text-gray-600">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                Fastest route available
              </li>
              <li className="flex items-center text-gray-600">
                <span className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></span>
                Multiple transport options
              </li>
              <li className="flex items-center text-gray-600">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                Real-time traffic updates
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}