// Existing interfaces...

export interface Carpool {
  id: string;
  startPoint: string;
  destination: string;
  date: string;
  time: string;
  availableSeats: number;
  price: number;
  carModel: string;
  carNumber: string;
  description?: string;
}