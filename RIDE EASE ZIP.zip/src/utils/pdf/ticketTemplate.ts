import { Ticket } from '../../types';

export interface TicketTemplateData {
  title: string;
  bookingDetails: {
    id: string;
    date: string;
    time: string;
  };
  journeyDetails: {
    from: string;
    to: string;
    transportType: string;
    passengers: number;
  };
  paymentDetails: {
    amount: number;
    method: string;
  };
}

export function createTicketTemplateData(ticket: Ticket): TicketTemplateData {
  return {
    title: 'RideEase Travel Ticket',
    bookingDetails: {
      id: ticket.bookingId,
      date: ticket.date,
      time: ticket.time,
    },
    journeyDetails: {
      from: ticket.from,
      to: ticket.to,
      transportType: ticket.transportType,
      passengers: ticket.passengers,
    },
    paymentDetails: {
      amount: ticket.fare,
      method: ticket.paymentMethod,
    },
  };
}