import { Ticket } from '../../types';
import { createTicketTemplateData } from './ticketTemplate';
import { generatePDF } from './pdfGenerator';

export function generateTicketPDF(ticket: Ticket): string {
  const templateData = createTicketTemplateData(ticket);
  return generatePDF(templateData);
}

export function downloadTicket(pdfData: string, filename: string): void {
  const link = document.createElement('a');
  link.href = pdfData;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}