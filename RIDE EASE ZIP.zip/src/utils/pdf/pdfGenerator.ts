import { jsPDF } from 'jspdf';
import type { TicketTemplateData } from './ticketTemplate';

export function generatePDF(template: TicketTemplateData): string {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header
  doc.setFontSize(20);
  doc.text(template.title, pageWidth/2, 20, { align: 'center' });
  
  // Booking Details
  doc.setFontSize(12);
  doc.text(`Booking ID: ${template.bookingDetails.id}`, 20, 40);
  doc.text(`Date: ${template.bookingDetails.date}`, 20, 50);
  doc.text(`Time: ${template.bookingDetails.time}`, 20, 60);
  
  // Journey Details
  doc.text('Journey Details:', 20, 80);
  doc.text(`From: ${template.journeyDetails.from}`, 30, 90);
  doc.text(`To: ${template.journeyDetails.to}`, 30, 100);
  doc.text(`Transport Type: ${template.journeyDetails.transportType}`, 30, 110);
  doc.text(`Passengers: ${template.journeyDetails.passengers}`, 30, 120);
  
  // Payment Details
  doc.text('Payment Details:', 20, 140);
  doc.text(`Amount Paid: ₹${template.paymentDetails.amount}`, 30, 150);
  doc.text(`Payment Method: ${template.paymentDetails.method}`, 30, 160);
  
  // Footer
  doc.setFontSize(10);
  doc.text('Thank you for choosing RideEase!', pageWidth/2, 200, { align: 'center' });
  
  return doc.output('datauristring');
}