interface ChatResponse {
  content: string;
}

const RESPONSES: Record<string, string[]> = {
  booking: [
    'To book a ride, click on "Book a Ride" in the navigation menu or use our route planner to find available options.',
    'You can book a ride by selecting your preferred route and clicking the "Book Now" button.',
  ],
  routes: [
    'You can plan your route by clicking on "Routes" in the navigation menu.',
    'Our route planner helps you find the best transportation options between any two points.',
  ],
  payment: [
    'We accept all major credit/debit cards for payments.',
    'Payment is processed securely at the end of your booking process.',
  ],
  schedule: [
    'You can view all available schedules when planning your route.',
    'Real-time updates are provided for all transportation options.',
  ],
  default: [
    'I'm here to help you with booking rides, finding routes, and answering any questions about our services.',
    'Could you please provide more details about what you're looking for?',
  ],
};

function findBestMatch(input: string): string {
  const lowercaseInput = input.toLowerCase();
  
  // Check for keywords in the input
  if (lowercaseInput.includes('book') || lowercaseInput.includes('reservation')) {
    return 'booking';
  }
  if (lowercaseInput.includes('route') || lowercaseInput.includes('path')) {
    return 'routes';
  }
  if (lowercaseInput.includes('pay') || lowercaseInput.includes('cost')) {
    return 'payment';
  }
  if (lowercaseInput.includes('schedule') || lowercaseInput.includes('time')) {
    return 'schedule';
  }
  
  return 'default';
}

export async function processUserMessage(message: string): Promise<string> {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const category = findBestMatch(message);
  const responses = RESPONSES[category];
  
  // Return a random response from the matching category
  return responses[Math.floor(Math.random() * responses.length)];
}