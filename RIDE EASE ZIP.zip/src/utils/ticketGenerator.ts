import jsPDF from 'jspdf';
import { Ticket } from '../types';

export function generateTicketPDF(ticket: Ticket): string {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header
  doc.setFontSize(20);
  doc.text('RideEase Travel Ticket', pageWidth/2, 20, { align: 'center' });
  
  // Booking Details
  doc.setFontSize(12);
  doc.text(`Booking ID: ${ticket.bookingId}`, 20, 40);
  doc.text(`Date: ${ticket.date}`, 20, 50);
  doc.text(`Time: ${ticket.time}`, 20, 60);
  
  // Journey Details
  doc.text('Journey Details:', 20, 80);
  doc.text(`From: ${ticket.from}`, 30, 90);
  doc.text(`To: ${ticket.to}`, 30, 100);
  doc.text(`Transport Type: ${ticket.transportType}`, 30, 110);
  doc.text(`Passengers: ${ticket.passengers}`, 30, 120);
  
  // Payment Details
  doc.text('Payment Details:', 20, 140);
  doc.text(`Amount Paid: ₹${ticket.fare}`, 30, 150);
  doc.text(`Payment Method: ${ticket.paymentMethod}`, 30, 160);
  
  // Footer
  doc.setFontSize(10);
  doc.text('Thank you for choosing RideEase!', pageWidth/2, 200, { align: 'center' });
  
  return doc.output('datauristring');
}